package testlink;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import testlink.api.java.client.TestLinkAPIClient;
import testlink.api.java.client.TestLinkAPIException;
import testlink.api.java.client.TestLinkAPIResults;

public class AutomatedTest {

	public static String DEVKEY="849db8a20151a50c568d6089c433573e";
	public static String URL="http://localhost/testlink-1.9.18/lib/api/xmlrpc/v1/xmlrpc.php";

public static void reportResult(String TestProject,String TestPlan,String Testcase,String Build,String Notes,String Result) throws TestLinkAPIException {
	TestLinkAPIClient api=new TestLinkAPIClient(DEVKEY, URL);
	api.reportTestCaseResult(TestProject, TestPlan, Testcase, Build, Notes, Result);

	}

@Test
	public void Test1()throws Exception
	{
		AutomatedTest a=new AutomatedTest();
		System.setProperty("webdriver.chrome.driver", "X:\\Gopi\\Gerty\\Web Drivers\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	WebDriverWait wait=new WebDriverWait(driver, 600);
	String testProject="ConvergentBanking";
	String testPlan="Convergent Banking Test Plan";
	String testCase="Validation of CB URL";
	String build="Jan 2019";
	String notes=null;
	String result=null;
	try{
	driver.manage().window().maximize();
	driver.get("https://getgopay-uat.unionbankph.com/login/email");
	Thread.sleep(2000);
	driver.findElement(By.id("email")).sendKeys("(003)gopinath.rajaram@unionbankph.com");
	result= TestLinkAPIResults.TEST_PASSED;
	notes="Executed successfully";
	System.out.println(notes);
	}
	catch(Exception e){
	result=TestLinkAPIResults.TEST_FAILED;
	notes="Execution failed";
	}
	finally{

		AutomatedTest.reportResult(testProject, testPlan, testCase, build, notes, result);
	driver.quit();
	}
	}
}
