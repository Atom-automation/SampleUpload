package cucmberCyclos;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions
			(
			features= {"X:\\Users\\6253\\eclipse-workspace\\sample.artifact\\DemoCyclos.feature"},
			glue={"X:\\Users\\6253\\eclipse-workspace\\sample.artifact\\src\\main\\java\\cucmberCyclos\\StepDefinationCyclos.java"},
			plugin = { "pretty", "html:X:\\Users\\6253\\eclipse-workspace\\sample.artifact\\target\\report\\cucumber-reports" },
			monochrome=true
			)

public class StepRunner {
	

}
