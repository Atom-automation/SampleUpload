package cucmberCyclos;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import sample.artifact.WrapperClass;

public class StepDefinationCyclos extends WrapperClass {
	 WebDriver driver;
	
	
	@Given("^I want launch the Demo cyclos url$")
	public void i_want_launch_the_Demo_cyclos_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "X:\\\\Gopi\\\\Gerty\\\\Web Drivers\\\\chromedriver.exe");
		driver= new ChromeDriver();	
		//driver.get("https://demo.cyclos.org/#login");
		 LaunchMthd(driver, "https://demo.cyclos.org/#login");		
		driver.manage().window().maximize();
		Thread.sleep(500);
	}

	@Given("^Enter valid credentials$")
	public void enter_valid_credentials() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		EnterByName(driver,"principal", "demo");
		EnterByName(driver,"password", "1234");
	   
	}

	@When("^I Click Login button$")
	public void i_Click_Login_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		ClickByClassName(driver, "actionButtonText");
		Thread.sleep(5000);
		
	}

	@Then("^I should see the Dasbhoard page$")
	public void i_should_see_the_Dasbhoard_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if(IsDisplayByXpath(driver, "//div[text()='Welcome to the Cyclos4 Demo']"))
		{
			System.out.println("Hey..I am in Dashboard page");
			
		}
		else
		{
			System.out.println("OOPS!!!!!something went wrong..Pls check your credentials");
		}
		
		driver.quit();
	}

}
