package sample.artifact;

public class Runtest {
	
	
	public static void add(int a,int b)
	{
		int a1 = 0;
		int b1 = 0;
		int c=a1+b;
		System.out.println(c);
	}
	
	public static void main(String[] args) {
		
		add(5,9);
		
		
	}

}
