package sample.artifact;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class WrapperClass {
	
	public static void EnterByName(WebDriver driver,String name,String value)
	{
		driver.findElement(By.name(name)).sendKeys(value);
	}

	 public static void ClickByClassName(WebDriver driver,String classname)
	 {
		 driver.findElement(By.className(classname)).click();
		 driver.findElement(By.className(classname)).getText();  
		 driver.findElement(By.className(classname)).getText();  
		 
	 }
	 
	// public static void ClickByXpath(WebDriver driver , String )
	 public static void LaunchMthd(WebDriver driver,String launch) 
	 {
		 driver.get(launch);
	 }
	 
	 public static boolean IsDisplayByXpath(WebDriver driver,String xpath)
	 {
		 try
		 {
		return driver.findElement(By.xpath(xpath)).isDisplayed();
		 }
		 catch(Exception ex)
		 {
			 
		 }
		return false;
			
	 }
}

