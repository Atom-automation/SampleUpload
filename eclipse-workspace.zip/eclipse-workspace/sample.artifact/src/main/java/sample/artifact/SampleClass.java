package sample.artifact;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SampleClass  extends WrapperClass  {
	static WebDriver driver;
	
	
	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO sysAuto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "X:\\\\Gopi\\\\Gerty\\\\Web Drivers\\\\chromedriver.exe");
		 driver= new ChromeDriver();
		//driver.get("https://demo.cyclos.org/#login");
		 LaunchMthd(driver, "https://demo.cyclos.org/#login");
		
		driver.manage().window().maximize();
		Thread.sleep(500);
		if(IsDisplayByXpath(driver, "/html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]/form/div/div[1]"))
		{
		//driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]/form/div/div[1]")).isDisplayed();
		EnterByName(driver,"principal", "demo");
		EnterByName(driver,"password", "1234");
		ClickByClassName(driver, "actionButtonText");
		//ClickByClassName(driver, "/html/body/div[3]/div[3]/div/div/div[1]/div/div/div[1]/div[2]/div[1]");
		//ClickByClassName(driver, classname);
		Thread.sleep(5000);
		}
		else
		{
			System.out.println("Element is not visible and hence closing the browser");
		}

		driver.quit();

	}


	

}
