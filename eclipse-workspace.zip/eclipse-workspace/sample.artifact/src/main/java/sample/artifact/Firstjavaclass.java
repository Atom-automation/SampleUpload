package sample.artifact;

import org.apache.xmlbeans.SystemProperties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Firstjavaclass {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
	    System.setProperty("webdriver.chrome.driver","X:\\\\\\\\Gopi\\\\\\\\Gerty\\\\\\\\Web Drivers\\\\\\\\chromedriver.exe");
	    WebDriver driver= new ChromeDriver();
	    
	    driver.get("https://demo.cyclos.org/");
	    Thread.sleep(500);
	    driver.manage().window().maximize();
	    driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/ul/li[2]/a/span")).click();
	    Thread.sleep(500);
	  
	    Thread.sleep(500);
	    driver.findElement(By.className("loginTitle")).isDisplayed();
	    Thread.sleep(500);
	    driver.findElement(By.name("principal")).sendKeys("demo");
	    Thread.sleep(500);
	    driver.findElement(By.name("password")).sendKeys("1234");
	    Thread.sleep(500);
	    driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]/form/div/button/div")).click();
	    Thread.sleep(500);
	    //driver.findElement(By.className("dashboardActionContainer")).click();
	    
	    Thread.sleep(500);
	    driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/ul/li[3]/a/span")).click();
	    Thread.sleep(500);
	    driver.findElement(By.className("gwt-InlineLabel")).click();
	   
	    Thread.sleep(1000);
	    driver.findElement(By.className("gwt-InlineLabel")).click();
	    Thread.sleep(1000);
	    driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/ul/li[5]/a/span")).click();
	    Thread.sleep(1000);
	    driver.quit();
		

	}

}
