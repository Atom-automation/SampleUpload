package sample.artifact;

import java.awt.RenderingHints.Key;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

//Need to launch this url - https://qz1lx46m.ngrok.io in chrome browser and login with this credentials
//   john@does.com
//   hello1234*
// X:\Gopi\Gerty\Web Drivers

public class SampleRun {
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "X:\\Gopi\\Gerty\\Web Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://qz1lx46m.ngrok.io");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("(//button[@type='button'])[1]")).click();
		Thread.sleep(10000);
		driver.findElement(By.id("email")).sendKeys("ab@mail.com");
		driver.findElement(By.id("email")).sendKeys(Keys.TAB);
		driver.findElement(By.xpath("(//button[@type='submit'])[1]")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("(//button[@type='button'])[3]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("mobile_number")).sendKeys("0000000000");
		driver.findElement(By.id("mobile_number")).sendKeys(Keys.TAB);
		driver.findElement(By.id("email")).sendKeys("ab@mail.com");
		driver.findElement(By.id("email")).sendKeys(Keys.TAB);
		driver.findElement(By.id("password")).sendKeys("Abcd@123");
		driver.findElement(By.id("password")).sendKeys(Keys.TAB);
		driver.findElement(By.id("confirm_password")).sendKeys("Abcd@123");
		driver.findElement(By.id("confirm_password")).sendKeys(Keys.TAB);
		driver.findElement(By.xpath("(//button[@type='submit'])[1]")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div[1]/div[1]/input")).sendKeys("0");
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div[1]/div[2]/input")).sendKeys("0");
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div[1]/div[3]/input")).sendKeys("0");
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div[1]/div[4]/input")).sendKeys("0");
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div[1]/div[5]/input")).sendKeys("0");
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div[1]/div[6]/input")).sendKeys("0");
		driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div[1]/div[6]/input")).sendKeys(Keys.TAB);
		driver.findElement(By.xpath("(//button[@type='button'])[3]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("first_name")).sendKeys("First");
		driver.findElement(By.id("first_name")).sendKeys(Keys.TAB);
		driver.findElement(By.id("middle_name")).sendKeys("Middle");
		driver.findElement(By.id("middle_name")).sendKeys(Keys.TAB);
		driver.findElement(By.id("last_name")).sendKeys("Last");
		driver.findElement(By.id("last_name")).sendKeys(Keys.TAB);
		//driver.findElement(By.xpath("(//*[@id=\"select-area-gender\"]/div[1]/div[2]/div/span/div/div/div/div")).click();
		


		Thread.sleep(2000);
		
				//driver.findElement(By.xpath("//a[text()='YES']")).click();
		//Thread.sleep(2000);
		//driver.findElement(By.id("card_number")).sendKeys("0000000000000000");
		//driver.findElement(By.id("card_number")).sendKeys(Keys.TAB);
		//Thread.sleep(5000);
		//driver.findElement(By.id("expiry_date")).click();
		//driver.findElement(By.xpath("//td[@title='Sep']")).click();
		//driver.findElement(By.id("expiry_date")).sendKeys(Keys.TAB);
		//driver.findElement(By.id("cvv")).sendKeys("000");
		//driver.findElement(By.id("email")).sendKeys("john@does.com");
		//driver.findElement(By.xpath("(//button[@type='submit'])[2]")).click();
		//Thread.sleep(2000);
		//driver.findElement(By.id("password")).sendKeys("hello1234*");
		//Thread.sleep(1000);
		//driver.findElement(By.xpath("(//button[@type='submit'])[3]")).click();
		//Thread.sleep(5000);
		//driver.findElement(By.xpath("//li[text()='Funds Transfer']")).click();
		//Thread.sleep(1000);
		//driver.findElement(By.xpath("//li[text()='Currency Converter']")).click();
		//Thread.sleep(1000);
		//driver.findElement(By.id("convert_from")).sendKeys("100");
		//Thread.sleep(500);
		//driver.findElement(By.id("convert_from")).sendKeys(Keys.TAB);
		
		//Thread.sleep(1000);
		//driver.findElement(By.xpath("(//button[@type='button'])")).click();
		//Thread.sleep(5000);
		driver.findElement(By.xpath("//li[text()='Beneficiaries']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//li[text()='Beneficiaries']")).click();
		Thread.sleep(500);
		
	}
	


}
