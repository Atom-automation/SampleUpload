package Trash;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class Sample {
	
	@SuppressWarnings("null")
	public static void main(String[] args) throws ParseException {
		
//		int[] age = {1,2,3,4,5,6};
//		for(int i=0;i<=5;++i)
//		
//		{
//			System.out.println(age[i]);
//		}
//		
//		
//		String a= "google-is-always-google-is";
//		
//		String[] aa=a.split("-");
//		
//		for(int i=0;i<aa.length;i++)
//		{
//		
//			
//		if(aa[i].contentEquals(aa[i+1]) || aa[i].contentEquals(aa[i+2]) ||aa[i].contentEquals(aa[i+3]))
//		{
//			System.out.println("duplicate value found and its "+aa[i]);
//		}
//		
//	
//		}
		
		String aaa="google is my google and its google";
		
		String [] a=aaa.split(" ");
		
		Set<String> sd=new HashSet<>();
		
		for (int j = 0; j < a.length; j++) {
			sd.add(a[j]);
			
		}
		
		for (int j = 0; j < a.length; j++) {
			System.out.println(sd);
			
		}
		
	}

}
